import os, sys

print("Hello")
sys.stdout.flush()
os._exit(1)
