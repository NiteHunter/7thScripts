import time

# Wait the given time
for i in range(2):
    print('apple\tbanana\tmelone\tcherry')
    print('pepper tomato\tcorn cabbage')
    print('apple banana\tmelone\tcherry2')
    print('pepper tomato\tcorn cabbage2')
    print('prompt> ')
    time.sleep(0.5)

