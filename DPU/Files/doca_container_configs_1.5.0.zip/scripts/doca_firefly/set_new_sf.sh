#!/bin/bash

#
# Copyright (c) 2021-2022 NVIDIA CORPORATION & AFFILIATES, ALL RIGHTS RESERVED.
#
# This software product is a proprietary product of NVIDIA CORPORATION &
# AFFILIATES (the "Company") and all right, title, and interest in and to the
# software product, including all associated intellectual property rights, are
# and shall remain exclusively with the Company.
#
# This software product is governed by the End User License Agreement
# provided with the software product.
#

#
# Create and bind a SF, marking it as "trusted"
#
# Arguments:
#  1. PCI Address
#  2. SF Number (Checks if already exists)
#  3. MAC Address (if absent, a random address will be generated)
#
# Examples:
#  1. Create SF with number "4" over Port 0 of the card:
#         ./set_new_sf.sh 0000:03:00.0 4
#  2. Create SF with number "5" over Port 0 of the card and a specific MAC address:
#         ./set_new_sf.sh 0000:03:00.0 5 aa:bb:cc:dd:ee:ff
#  3. Create SF with number "4" over Port 1 of the card:
#         ./set_new_sf.sh 0000:03:00.1 4
#
# Both examples 1 and 2 should work out of the box for a BF2 device and create SF4 and SF5.
#

FILE=/opt/mellanox/iproute2/sbin/mlxdevm
if [ ! -f "$FILE" ]; then
    echo "$FILE is missing, cannot continue!"
    exit 1
fi

PCI=$1
PFNUM=${PCI: -1}
SFNUM=$2
hexchars="0123456789abcdef"
if [ -z $3 ]; then
    echo "No MAC given, generating randomly"
    SFMAC=$( for i in {1..12} ; do echo -n ${hexchars:$(( $RANDOM % 16 )):1} ; done | sed -e 's/\(..\)/\1:/g'  -e 's/^\(.\)[13579bdf]/\10/')
    SFMAC=${SFMAC:: -1}
else
    SFMAC=$3
fi
echo "Using MAC - $SFMAC"
NEXTSF=$(($(ls /sys/bus/auxiliary/devices/mlx5_core.* | grep -o .sf.* | tail -1 | sed 's/[^0-9]*//g') + 1))
echo "Next SF is $NEXTSF"

DEV=$(/opt/mellanox/iproute2/sbin/mlxdevm port add pci/"$PCI" flavour pcisf pfnum "$PFNUM" sfnum "$SFNUM" controller 0)
echo $DEV
if [ -z "$DEV" ]; then
	echo "Adding SF failed, aborting"
	exit 1
fi

PARSE_DEV=${DEV##*/}
echo $PARSE_DEV
PARSE_DEV=${PARSE_DEV%: *}
echo $PARSE_DEV
/opt/mellanox/iproute2/sbin/mlxdevm port function set pci/"$PCI"/"$PARSE_DEV" hw_addr "$SFMAC"
/opt/mellanox/iproute2/sbin/mlxdevm port function set pci/"$PCI"/"$PARSE_DEV" trust on state active
/opt/mellanox/iproute2/sbin/mlxdevm port show pci/"$PCI"/"$PARSE_DEV"

sleep 1

echo "Rebinding SFs is needed on BF2 device"
echo mlx5_core.sf."$NEXTSF" > /sys/bus/auxiliary/drivers/mlx5_core.sf_cfg/unbind
echo mlx5_core.sf."$NEXTSF" > /sys/bus/auxiliary/drivers/mlx5_core.sf/bind

ls /sys/bus/auxiliary/devices/mlx5_core.* | grep "$NEXTSF"
retcode=$?
if [[ "$retcode" == "0" ]]; then
    echo "SF was created successfully"
else
    echo "Failed to create the SF"
fi
exit $retcode
