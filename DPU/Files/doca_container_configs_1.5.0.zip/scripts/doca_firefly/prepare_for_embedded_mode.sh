#!/bin/bash

#
# Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES, ALL RIGHTS RESERVED.
#
# This software product is a proprietary product of NVIDIA CORPORATION &
# AFFILIATES (the "Company") and all right, title, and interest in and to the
# software product, including all associated intellectual property rights, are
# and shall remain exclusively with the Company.
#
# This software product is governed by the End User License Agreement
# provided with the software product.
#

#
# Prepare the OVS and SF settings needed for Firefly in Embeeded Mode
#
# Arguments:
#  1. SF Number (Checks if already exists)
#
# Examples:
#  Prepare the OVS settings using a SF indexed 4, as shown in the user guide:
#         ./prepare_for_embedded_mode.sh 4
#

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
FILE=${SCRIPT_DIR}/set_new_sf.sh
if [ ! -f "$FILE" ]; then
    echo "$FILE is missing, cannot continue!"
    exit 1
fi

SFNUM=$1

echo "Removing all existing OVS bridges"
for bridge in `ovs-vsctl list-br`; do
    ovs-vsctl del-br $bridge
done

echo "Creating OVS bridge for p0"
ovs-vsctl add-br uplink
ovs-vsctl add-port uplink p0
ovs-vsctl add-port uplink pf0hpf

echo "Creating a trusted SF to be used by Firefly"
${FILE} 0000:03:00.0 ${SFNUM}
retcode=$?
if [[ "$retcode" != "0" ]]; then
    echo "Failed to create the SF"
    exit $returncode
fi
sleep 2

# Find the interface names for the SF
SF_IFACE=enp3s0f0s${SFNUM}
SF_REP=en3f0pf0sf${SFNUM}

echo "Linking the representor of the SF to the OVS bridge"
ovs-vsctl add-port uplink ${SF_REP}

echo "Enabling Tx port timestamping for interface ${SF_IFACE}"
ethtool --set-priv-flags ${SF_IFACE} tx_port_ts on
retcode=$?
if [[ "$retcode" != "0" ]]; then
    echo "Failed to create set Tx timestamping for the interface"
    exit $returncode
fi

ovs-vsctl set Bridge uplink mcast_snooping_enable=true
ovs-vsctl set Port ${SF_REP} other_config:mcast-snooping-flood=true
ovs-vsctl set Port ${SF_REP} other_config:mcast-snooping-flood-reports=true

tc filter add dev ${SF_REP} protocol ipv4 parent ffff: prio 1000 flower ip_proto udp dst_port 319 skip_sw action mirred egress redirect dev p0
tc filter add dev ${SF_REP} protocol ipv4 parent ffff: prio 1000 flower ip_proto udp dst_port 320 skip_sw action mirred egress redirect dev p0
tc filter add dev p0 protocol ipv4 parent ffff: prio 1000 flower ip_proto udp dst_port 319 skip_sw action mirred egress redirect dev ${SF_REP}
tc filter add dev p0 protocol ipv4 parent ffff: prio 1000 flower ip_proto udp dst_port 320 skip_sw action mirred egress redirect dev ${SF_REP}

echo "All set, please set an IP address to the SF interface: ${SF_IFACE}"
exit 0
