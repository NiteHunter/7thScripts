#!/bin/bash

SCRIPTNAME=`basename "$0"`
HBN_CONFIG_DIR="/var/lib/hbn"

usage () {
	echo "usage: $SCRIPTNAME"
	echo "$SCRIPTNAME            configure DPU for HBN with MISC ECMP Settings"
	echo "$SCRIPTNAME --bond     configure DPU for HBN with bond"
	echo "$SCRIPTNAME -u|--username <username> -p|--password Create user on HBN with specified username and password"
	exit 0
}

addUser () {
	username=$1
	password=$2
	mkdir -p "$HBN_CONFIG_DIR"/etc/hbn-users
	/usr/bin/python3 encrypt_password.py -u $username -p $password
	exit 0
}

if [ "$1" == "-h" ] || [ "$1" == "help" ]; then
	usage
fi

if [ "$1" == "-u" ] || [ "$1" == "--username" ]; then
    username=$2
    if [ "$3" == "-p" ] || [ "$3" == "--password" ]; then
        password=$4
        addUser $username $password
    else
        usage
    fi
fi

if [ "$#" -gt 0 ]; then
	echo "unknown argument"
	usage
fi

mst_dev=$(mst status | grep /dev/mst | cut -d" " -f1)

# Set embedded cpu mode if needed
embedded_mode_set=$(mlxconfig -d "$mst_dev" q INTERNAL_CPU_MODEL | grep "EMBEDDED_CPU(1)")
embedded_mode1_set=$(mlxconfig -d "$mst_dev".1 q INTERNAL_CPU_MODEL | grep "EMBEDDED_CPU(1)")
if [ -z "$embedded_mode_set" ] || [ -z "$embedded_mode1_set" ]; then
        echo y | mlxconfig -d /dev/mst/mt41686_pciconf0 s INTERNAL_CPU_MODEL=1
        echo y | mlxconfig -d /dev/mst/mt41686_pciconf0.1 s INTERNAL_CPU_MODEL=1
        echo Please power cycle DPU and host server to set embedded CPU mode
        exit
fi

# Start mst service if needed
mst_started=$(mst status | grep "configuration module loaded")
if [ -z "$mst_started" ]; then
        mst start
fi

# Set up internal LAG in HASH mode
lag_hash=$(mlxconfig -d "$mst_dev" -e q LAG_RESOURCE_ALLOCATION | grep "LAG_RESOURCE_ALLOCATION" | tr -s ' ' | cut -d ' ' -f 4)
if [ "$lag_hash" != "PRE_ALLOCATION(1)" ]; then
	echo y | mlxconfig -d "$mst_dev" s LAG_RESOURCE_ALLOCATION=1
	echo please power cycle host server to finish ECMP/LAG setup
fi

grub_vrf=$(grep "cgroup_no_v1=net_prio,net_cls" /etc/default/grub)
if [ -z "$grub_vrf" ]; then
	sed -i 's/CMDLINE_LINUX_DEFAULT="/CMDLINE_LINUX_DEFAULT="cgroup_no_v1=net_prio,net_cls /g' /etc/default/grub
	sudo update-grub > /dev/null 2>&1
	echo "Grub configuration updated for VRF support, please reboot DPU"
fi

if ! grep -q ENCAP_NONE_MODE /etc/mellanox/mlnx-bf.conf; then
	echo "ENCAP_NONE_MODE=yes" >> /etc/mellanox/mlnx-bf.conf
fi

if ! grep -q LAG_MULTIPORT_ESW_MODE /etc/mellanox/mlnx-bf.conf; then
	echo "LAG_MULTIPORT_ESW_MODE=yes" >> /etc/mellanox/mlnx-bf.conf
fi

cat > /etc/rc-bf2.local << EOF
#!/bin/sh -e

# Update ebtables/iptables and ip6tables to point to legacy
update-alternatives --install /usr/sbin/ebtables ebtables /usr/sbin/ebtables-legacy 20 \
	        --slave /usr/sbin/ebtables-restore ebtables-restore /usr/sbin/ebtables-legacy-restore \
		--slave /usr/sbin/ebtables-save ebtables-save /usr/sbin/ebtables-legacy-save
 
update-alternatives --install /usr/sbin/iptables iptables /usr/sbin/iptables-legacy 20 \
	        --slave /usr/sbin/iptables-restore iptables-restore /usr/sbin/iptables-legacy-restore \
		--slave /usr/sbin/iptables-save iptables-save /usr/sbin/iptables-legacy-save
 
update-alternatives --install /usr/sbin/ip6tables ip6tables /usr/sbin/ip6tables-legacy 20 \
	        --slave /usr/sbin/ip6tables-restore ip6tables-restore /usr/sbin/ip6tables-legacy-restore \
		--slave /usr/sbin/ip6tables-save ip6tables-save /usr/sbin/ip6tables-legacy-save
 
# Load the modules
ebtables -t filter -L > /dev/null
iptables -t filter -L > /dev/null
ip6tables -t filter -L > /dev/null

# Enable docker forwarding
iptables -P FORWARD ACCEPT

# Enable IPv4/IPv6 kernel forwarding
echo 1 > /proc/sys/net/ipv4/ip_forward
echo 1 > /proc/sys/net/ipv6/conf/all/forwarding

# Setting up huge tables for DPDK
echo 1024 > /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages

#capture the DPU image info
echo "BFB Image info:" > /var/log/doca/hbn/dpu_info.log
cat  /etc/mlnx-release >> /var/log/doca/hbn/dpu_info.log
echo "" >> /var/log/doca/hbn/dpu_info.log
echo "FW info:" >> /var/log/doca/hbn/dpu_info.log
mlxfwmanager >> /var/log/doca/hbn/dpu_info.log

EOF

cat > /usr/lib/systemd/system/rc-bf2-local.service << EOF
[Unit]
Description=/etc/rc-bf2.local Compatibility
Documentation=man:systemd-rc-local-generator(8)
ConditionFileIsExecutable=/etc/rc-bf2.local
Before=kubelet.service
Wants=network-online.target
After=network-online.target

[Service]
Type=forking
ExecStart=/etc/rc-bf2.local start
TimeoutSec=0
RemainAfterExit=yes
GuessMainPID=no

[Install]
WantedBy=multi-user.target
EOF

chmod +x /etc/rc-bf2.local
systemctl daemon-reload > /dev/null
systemctl enable rc-bf2-local > /dev/null

mkdir -p "$HBN_CONFIG_DIR"/etc/frr

if [ ! -e "$HBN_CONFIG_DIR"/etc/frr/daemons ]; then
	cp etc/frr/frr.daemons "$HBN_CONFIG_DIR"/etc/frr/daemons
fi

if [ ! -e "$HBN_CONFIG_DIR"/etc/frr/frr.conf ]; then
	cp etc/frr/frr.conf "$HBN_CONFIG_DIR"/etc/frr/frr.conf
fi

if [ ! -e "$HBN_CONFIG_DIR"/etc/frr/vtysh.conf ]; then
	cp etc/frr/vtysh.conf "$HBN_CONFIG_DIR"/etc/frr/vtysh.conf
fi

if [ ! -e "$HBN_CONFIG_DIR"/etc/frr/support_bundle_commands.conf ]; then
	cp etc/frr/support_bundle_commands.conf "$HBN_CONFIG_DIR"/etc/frr/support_bundle_commands.conf
fi

mkdir -p "$HBN_CONFIG_DIR"/etc/network/
touch "$HBN_CONFIG_DIR"/etc/network/interfaces

if ! grep -q "iface p0" "$HBN_CONFIG_DIR"/etc/network/interfaces; then
	cp network.interfaces "$HBN_CONFIG_DIR"/etc/network/interfaces
fi

mkdir -p "$HBN_CONFIG_DIR"/etc/network/ifupdown2

if [ ! -e "$HBN_CONFIG_DIR"/etc/network/ifupdown2/addons.conf ]; then
	cp ifupdown2/addons.conf "$HBN_CONFIG_DIR"/etc/network/ifupdown2/addons.conf
fi

if [ ! -e "$HBN_CONFIG_DIR"/etc/network/ifupdown2/ifupdown2.conf ]; then
	cp ifupdown2/ifupdown2.conf "$HBN_CONFIG_DIR"/etc/network/ifupdown2/ifupdown2.conf
fi

mkdir -p "$HBN_CONFIG_DIR"/var/lib/nvue

mkdir -p "$HBN_CONFIG_DIR"/etc/supervisor/conf.d/

mkdir -p "$HBN_CONFIG_DIR"/etc/nvue.d

if [ ! -e "$HBN_CONFIG_DIR"/etc/supervisor/conf.d/supervisor-isc-dhcp-relay.conf ]; then
        cp etc/supervisor/conf.d/supervisor-isc-dhcp-relay.conf "$HBN_CONFIG_DIR"/etc/supervisor/conf.d/supervisor-isc-dhcp-relay.conf
fi

if [ ! -e "$HBN_CONFIG_DIR"/etc/supervisor/conf.d/supervisor-isc-dhcp-relay6.conf ]; then
        cp etc/supervisor/conf.d/supervisor-isc-dhcp-relay6.conf "$HBN_CONFIG_DIR"/etc/supervisor/conf.d/supervisor-isc-dhcp-relay6.conf
fi

mkdir -p "$HBN_CONFIG_DIR"/etc/hbn-users

# create persistent log directory
mkdir -p /var/log/doca/hbn/supervisor

mkdir -p "$HBN_CONFIG_DIR"/var/support/core

mkdir -p "$HBN_CONFIG_DIR"/etc/cumulus

if [ ! -e "$HBN_CONFIG_DIR"/etc/cumulus/nl2docad.conf ]; then
	cp -r etc/cumulus "$HBN_CONFIG_DIR"/etc/
fi

if [ ! -e "$HBN_CONFIG_DIR"/etc/cumulus/acl/policy.d/02hbn_internal.rules ]; then
	cp -r etc/cumulus/acl/policy.d/02hbn_internal.rules "$HBN_CONFIG_DIR"/etc/cumulus/acl/policy.d/02hbn_internal.rules
fi

echo "HBN setup done for SFC ECMP configuration"
echo "Please reboot DPU to setup SFC ECMP Settings"

